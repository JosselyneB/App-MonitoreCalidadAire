package com.example.calidadaireapp

class SensorRepository(
    private val apiService: ApiService
) {

    /**
     * Obtiene las últimas mediciones desde el backend
     * Usa el endpoint: /registros/ultimos
     */
    suspend fun obtenerUltimos(ubicacion: String): List<RegistroSensor> {
        return apiService.obtenerUltimos(ubicacion)
    }

    /**
     * Obtiene el histórico completo desde el backend
     * Usa el endpoint: /registros/todos
     * (para gráficas y reportes CSV)
     */
    suspend fun obtenerHistorico(ubicacion: String): List<RegistroSensor> {
        return apiService.obtenerTodos(ubicacion)
    }
}
