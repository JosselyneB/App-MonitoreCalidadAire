package com.example.calidadaireapp

import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {

    // 🔹 Para dashboard (últimos valores)
    @GET("registros/ultimos")
    suspend fun obtenerUltimos(
        @Query("ubicacion") ubicacion: String
    ): List<RegistroSensor>

    // 🔹 Para reportes CSV (TODOS los datos)
    @GET("registros/todos")
    suspend fun obtenerTodos(
        @Query("ubicacion") ubicacion: String
    ): List<RegistroSensor>
}
