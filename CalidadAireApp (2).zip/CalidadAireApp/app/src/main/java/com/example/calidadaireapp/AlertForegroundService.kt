package com.example.calidadaireapp

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.util.concurrent.TimeUnit

class AlertForegroundService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val repository by lazy {
        SensorRepository(ApiClient.api)
    }

    // ================== PREFS ==================
    private fun getPrefs(): android.content.SharedPreferences {
        return getSharedPreferences("alertas_prefs", Context.MODE_PRIVATE)
    }

    override fun onCreate() {
        super.onCreate()
        iniciarServicioEnPrimerPlano()
        iniciarMonitoreo()
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ================== FOREGROUND ==================
    private fun iniciarServicioEnPrimerPlano() {
        val notification: Notification =
            NotificationCompat.Builder(this, "alertas_calidad_aire")
                .setContentTitle("Monitoreo activo")
                .setContentText("Vigilando calidad del aire en parqueaderos")
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setOngoing(true)
                .build()

        startForeground(1001, notification)
    }

    // ================== MONITOREO ==================
    private fun iniciarMonitoreo() {
        serviceScope.launch {
            while (isActive) {
                verificarParqueadero("Parqueadero 1")
                verificarParqueadero("Parqueadero 2")

                delay(TimeUnit.MINUTES.toMillis(5)) // ⏱ cada 5 minutos
            }
        }
    }

    private suspend fun verificarParqueadero(ubicacion: String) {
        try {
            val datos = repository.obtenerUltimos(ubicacion)
            if (datos.isEmpty()) return

            val ultimoPorSensor = datos
                .groupBy { SensorUtils.normalizarSensor(it.sensor) }
                .mapValues { it.value.maxByOrNull { r -> r.timestamp }!! }

            val prefs = getPrefs()

            ultimoPorSensor.forEach { (sensor, registro) ->
                val key = "${registro.ubicacion}-${sensor}"
                val estadoActual = registro.estado.uppercase()
                val estadoAnterior = prefs.getString(key, null)

                // 🔔 ALERTA SOLO SI CAMBIA A MALO
                if (estadoActual == "MALO" && estadoAnterior != "MALO") {
                    mostrarAlerta(sensor, ubicacion)
                }

                // 💾 Guardar estado SIEMPRE
                prefs.edit()
                    .putString(key, estadoActual)
                    .apply()
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // ================== ALERTA ==================
    private fun mostrarAlerta(sensor: String, ubicacion: String) {
        val notification = NotificationCompat.Builder(this, "alertas_calidad_aire")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("⚠️ ALERTA DE CALIDAD DEL AIRE")
            .setContentText("$sensor en $ubicacion está en estado MALO")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_SOUND)
            .build()

        val manager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
