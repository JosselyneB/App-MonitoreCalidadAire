package com.example.calidadaireapp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.card.MaterialCardView
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    // ================== CONFIG ==================
    private var ubicacionActual = "Parqueadero 1"

    /**
     * Guarda el último estado por parqueadero + sensor
     * Ejemplo: "Parqueadero 2-CO"
     */
    private val ultimoEstadoPorSensor = mutableMapOf<String, String>()

    private val repository by lazy {
        SensorRepository(ApiClient.api)
    }

    // ================== UI ==================
    private lateinit var tvCOValue: TextView
    private lateinit var tvCO2Value: TextView
    private lateinit var tvPM25Value: TextView
    private lateinit var tvUbicacion: TextView

    private lateinit var btnReports: Button
    private lateinit var btnParqueadero1: Button
    private lateinit var btnParqueadero2: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        crearCanalNotificacion()
        iniciarServicioAlertas() // ✅ FOREGROUND SERVICE
        bindUI()
        setListeners()
        cargarDatos()
    }

    // ================== FOREGROUND SERVICE ==================
    private fun iniciarServicioAlertas() {
        val intent = Intent(this, AlertForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    // ================== UI ==================
    private fun bindUI() {
        tvCOValue = findViewById(R.id.tvCOValue)
        tvCO2Value = findViewById(R.id.tvCO2Value)
        tvPM25Value = findViewById(R.id.tvPM25Value)
        tvUbicacion = findViewById(R.id.tvUbicacion)

        btnReports = findViewById(R.id.btnReports)
        btnParqueadero1 = findViewById(R.id.btnParqueadero1)
        btnParqueadero2 = findViewById(R.id.btnParqueadero2)

        actualizarTituloUbicacion()
        resetValores()
    }

    private fun setListeners() {

        btnParqueadero1.setOnClickListener {
            ubicacionActual = "Parqueadero 1"
            actualizarTituloUbicacion()
            cargarDatos()
        }

        btnParqueadero2.setOnClickListener {
            ubicacionActual = "Parqueadero 2"
            actualizarTituloUbicacion()
            cargarDatos()
        }

        findViewById<MaterialCardView>(R.id.cardCO)
            .setOnClickListener { openSensor("CO") }

        findViewById<MaterialCardView>(R.id.cardCO2)
            .setOnClickListener { openSensor("CO2") }

        findViewById<MaterialCardView>(R.id.cardPM25)
            .setOnClickListener { openSensor("PM25") }

        btnReports.setOnClickListener {
            startActivity(Intent(this, ReportActivity::class.java))
        }
    }

    private fun actualizarTituloUbicacion() {
        tvUbicacion.text = ubicacionActual
    }

    private fun resetValores() {
        tvCOValue.text = "--"
        tvCO2Value.text = "--"
        tvPM25Value.text = "--"
    }

    // ================== DATOS + ALERTAS (APP ABIERTA) ==================
    private fun cargarDatos() {
        lifecycleScope.launch {
            try {
                val datos = repository.obtenerUltimos(ubicacionActual)

                if (datos.isEmpty()) {
                    resetValores()
                    return@launch
                }

                val ultimoPorSensor = datos
                    .groupBy { SensorUtils.normalizarSensor(it.sensor) }
                    .mapValues { it.value.maxByOrNull { r -> r.timestamp }!! }

                procesarSensor("CO", ultimoPorSensor["CO"], tvCOValue, "ppm")
                procesarSensor("CO2", ultimoPorSensor["CO2"], tvCO2Value, "ppm")
                procesarSensor("PM25", ultimoPorSensor["PM25"], tvPM25Value, "µg/m³")

            } catch (e: Exception) {
                e.printStackTrace()
                resetValores()
            }
        }
    }

    private fun procesarSensor(
        sensor: String,
        registro: RegistroSensor?,
        textView: TextView,
        unidad: String
    ) {
        registro ?: return

        textView.text = "${registro.valor} $unidad"

        val estadoActual = registro.estado.uppercase()
        val key = "$ubicacionActual-$sensor"
        val estadoAnterior = ultimoEstadoPorSensor[key]

        // 🔔 ALERTA SOLO SI CAMBIA A MALO (APP ABIERTA)
        if (estadoActual == "MALO" && estadoAnterior != "MALO") {
            mostrarNotificacion(
                "⚠️ Alerta de Calidad del Aire",
                "$sensor en $ubicacionActual está en estado MALO"
            )
            vibrar()
        }

        ultimoEstadoPorSensor[key] = estadoActual
    }

    // ================== NOTIFICACIONES ==================
    private fun crearCanalNotificacion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "alertas_calidad_aire",
                "Alertas de Calidad del Aire",
                NotificationManager.IMPORTANCE_HIGH
            )
            val manager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun mostrarNotificacion(titulo: String, mensaje: String) {
        val notification = NotificationCompat.Builder(this, "alertas_calidad_aire")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(titulo)
            .setContentText(mensaje)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_SOUND)
            .build()

        val manager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(System.currentTimeMillis().toInt(), notification)
    }

    private fun vibrar() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(
                VibrationEffect.createOneShot(
                    500,
                    VibrationEffect.DEFAULT_AMPLITUDE
                )
            )
        } else {
            vibrator.vibrate(500)
        }
    }

    // ================== DETALLE SENSOR ==================
    private fun openSensor(sensor: String) {
        val intent = Intent(this, SensorDetailActivity::class.java)
        intent.putExtra("SENSOR", sensor)
        intent.putExtra("UBICACION", ubicacionActual)
        startActivity(intent)
    }
}
