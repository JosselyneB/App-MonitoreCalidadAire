package com.example.calidadaireapp

import android.graphics.Color
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class SensorDetailActivity : AppCompatActivity() {

    // ===== UI =====
    private lateinit var chart: LineChart
    private lateinit var tvTitle: TextView
    private lateinit var tvValue: TextView
    private lateinit var tvUnit: TextView
    private lateinit var tvEstado: TextView

    // ===== REPO =====
    private val repository by lazy {
        SensorRepository(ApiClient.api)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sensor_detail)

        // UI
        chart = findViewById(R.id.lineChart)
        tvTitle = findViewById(R.id.tvSensorTitle)
        tvValue = findViewById(R.id.tvSensorValue)
        tvUnit = findViewById(R.id.tvSensorUnit)
        tvEstado = findViewById(R.id.tvSensorEstado)

        val sensor = intent.getStringExtra("SENSOR") ?: return
        val ubicacion = intent.getStringExtra("UBICACION") ?: return

        configurarUI(sensor)
        cargarHistorico(sensor, ubicacion)
    }

    // ================== CONFIGURACIÓN VISUAL ==================
    private fun configurarUI(sensor: String) {
        when (sensor.uppercase()) {
            "CO" -> {
                tvTitle.text = "Monóxido de Carbono (CO)"
                tvUnit.text = "ppm"
            }
            "CO2" -> {
                tvTitle.text = "Dióxido de Carbono (CO₂)"
                tvUnit.text = "ppm"
            }
            "PM25" -> {
                tvTitle.text = "Partículas PM2.5"
                tvUnit.text = "µg/m³"
            }
        }
    }

    // ================== DATOS HISTÓRICOS ==================
    private fun cargarHistorico(sensor: String, ubicacion: String) {
        lifecycleScope.launch {
            try {
                val datos = repository.obtenerHistorico(ubicacion)
                    .filter {
                        SensorUtils.normalizarSensor(it.sensor) ==
                                SensorUtils.normalizarSensor(sensor)
                    }
                    .sortedBy { it.timestamp }

                if (datos.isEmpty()) {
                    tvValue.text = "--"
                    tvEstado.text = "ESTADO ACTUAL: SIN DATOS"
                    chart.clear()
                    chart.invalidate()
                    return@launch
                }

                val ultimo = datos.last()

                tvValue.text = ultimo.valor.toString()
                tvEstado.text = "ESTADO ACTUAL: ${ultimo.estado}"

                pintarEstado(ultimo.estado)
                dibujarGrafico(datos)

            } catch (e: Exception) {
                tvValue.text = "Error"
                tvEstado.text = "ESTADO ACTUAL: --"
                chart.clear()
                chart.invalidate()
                e.printStackTrace()
            }
        }
    }

    // ================== GRÁFICO ==================
    private fun dibujarGrafico(datos: List<RegistroSensor>) {

        val entries = datos.mapIndexed { index, registro ->
            Entry(index.toFloat(), registro.valor)
        }

        val color = Color.parseColor("#1565C0")

        val dataSet = LineDataSet(entries, "Histórico").apply {
            this.color = color
            setCircleColor(color)
            lineWidth = 2.5f
            circleRadius = 4f
            setDrawFilled(true)
            fillColor = color
            fillAlpha = 40
            setDrawValues(false)
        }

        chart.data = LineData(dataSet)

        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    val index = value.toInt()
                    return if (index in datos.indices) {
                        timeFormat.format(Date(datos[index].timestamp))
                    } else ""
                }
            }
        }

        chart.axisRight.isEnabled = false
        chart.description.isEnabled = false
        chart.invalidate()
    }

    // ================== ESTADO ==================
    private fun pintarEstado(estado: String) {
        when (estado.uppercase()) {
            "BUENO" -> tvEstado.setTextColor(Color.parseColor("#2E7D32"))
            "MODERADO" -> tvEstado.setTextColor(Color.parseColor("#F9A825"))
            "MALO" -> tvEstado.setTextColor(Color.parseColor("#C62828"))
        }
    }
}
