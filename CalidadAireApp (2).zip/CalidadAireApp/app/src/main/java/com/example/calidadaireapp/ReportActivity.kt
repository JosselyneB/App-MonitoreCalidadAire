package com.example.calidadaireapp

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.chip.Chip
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class ReportActivity : AppCompatActivity() {

    // ===== UI =====
    private lateinit var cbCO: CheckBox
    private lateinit var cbCO2: CheckBox
    private lateinit var cbPM25: CheckBox

    private lateinit var chipToday: Chip
    private lateinit var chip7: Chip
    private lateinit var chip30: Chip
    private lateinit var chip90: Chip

    private lateinit var etStartDate: TextInputEditText
    private lateinit var etEndDate: TextInputEditText

    private lateinit var btnCancel: Button
    private lateinit var btnDownload: Button

    // ===== FECHAS =====
    private var startDateMillis: Long? = null
    private var endDateMillis: Long? = null

    // ===== CONFIG =====
    private val ubicacion = "Parqueadero 1"

    private val repository by lazy {
        SensorRepository(ApiClient.api)
    }

    private val dateFormatter =
        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    private val fileDateFormatter =
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    private val csvFormatter =
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report)

        bindUI()
        setListeners()
    }

    // ================== UI ==================
    private fun bindUI() {
        cbCO = findViewById(R.id.cbCO)
        cbCO2 = findViewById(R.id.cbCO2)
        cbPM25 = findViewById(R.id.cbPM25)

        chipToday = findViewById(R.id.chipToday)
        chip7 = findViewById(R.id.chip7)
        chip30 = findViewById(R.id.chip30)
        chip90 = findViewById(R.id.chip90)

        etStartDate = findViewById(R.id.etStartDate)
        etEndDate = findViewById(R.id.etEndDate)

        btnCancel = findViewById(R.id.btnCancel)
        btnDownload = findViewById(R.id.btnDownload)
    }

    private fun setListeners() {

        etStartDate.setOnClickListener { openDatePicker(true) }
        etEndDate.setOnClickListener { openDatePicker(false) }

        chipToday.setOnClickListener { setQuickRange(0) }
        chip7.setOnClickListener { setQuickRange(7) }
        chip30.setOnClickListener { setQuickRange(30) }
        chip90.setOnClickListener { setQuickRange(90) }

        btnCancel.setOnClickListener { finish() }

        btnDownload.setOnClickListener {
            if (validateSelection() && validateDateRange()) {
                generarCSV()
            }
        }
    }

    // ================== CSV ==================
    private fun generarCSV() {
        lifecycleScope.launch {
            try {
                val sensoresSeleccionados = mutableSetOf<String>()
                if (cbCO.isChecked) sensoresSeleccionados.add("CO")
                if (cbCO2.isChecked) sensoresSeleccionados.add("CO2")
                if (cbPM25.isChecked) sensoresSeleccionados.add("PM25")

                val datos = repository.obtenerHistorico(ubicacion)
                    .filter {
                        SensorUtils.normalizarSensor(it.sensor) in sensoresSeleccionados
                    }
                    .filter {
                        val ts = normalizarTimestamp(it.timestamp)
                        ts in startDateMillis!!..endDateMillis!!
                    }
                    .sortedBy { it.timestamp }

                if (datos.isEmpty()) {
                    Toast.makeText(
                        this@ReportActivity,
                        "No hay datos para el rango seleccionado",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@launch
                }

                val fechaInicio = fileDateFormatter.format(Date(startDateMillis!!))
                val fechaFin = fileDateFormatter.format(Date(endDateMillis!!))

                val fileName = "Reporte_${fechaInicio}_a_${fechaFin}.csv"
                val file = File(getExternalFilesDir(null) ?: filesDir, fileName)

                file.bufferedWriter().use { writer ->
                    // ENCABEZADO
                    writer.write("Fecha,Sensor,Valor,Estado,Unidad,Ubicacion\n")

                    datos.forEach { r ->
                        val tsSeguro = normalizarTimestamp(r.timestamp)
                        val fecha = csvFormatter.format(Date(tsSeguro))

                        writer.write(
                            "$fecha,${r.sensor},${r.valor},${r.estado},${r.unidad},${r.ubicacion}\n"
                        )
                    }
                }

                Toast.makeText(
                    this@ReportActivity,
                    "Reporte generado correctamente\n${file.absolutePath}",
                    Toast.LENGTH_LONG
                ).show()

            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(
                    this@ReportActivity,
                    "Error al generar el reporte",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    // ================== FECHAS ==================
    private fun openDatePicker(isStart: Boolean) {
        val picker = MaterialDatePicker.Builder.datePicker()
            .setTitleText(if (isStart) "Fecha inicio" else "Fecha fin")
            .build()

        picker.addOnPositiveButtonClickListener { millis ->
            if (isStart) {
                startDateMillis = millis
                etStartDate.setText(dateFormatter.format(Date(millis)))
            } else {
                endDateMillis = millis
                etEndDate.setText(dateFormatter.format(Date(millis)))
            }
        }

        picker.show(
            supportFragmentManager,
            if (isStart) "START_DATE" else "END_DATE"
        )
    }

    /**
     * Rangos basados en la FECHA ACTUAL (no 1970, no datos viejos)
     */
    private fun setQuickRange(days: Int) {
        val cal = Calendar.getInstance()

        // FIN: hoy 23:59:59.999
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        endDateMillis = cal.timeInMillis

        if (days == 0) {
            // INICIO: hoy 00:00
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            startDateMillis = cal.timeInMillis
        } else {
            cal.add(Calendar.DAY_OF_YEAR, -days)
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            startDateMillis = cal.timeInMillis
        }

        etStartDate.setText(dateFormatter.format(Date(startDateMillis!!)))
        etEndDate.setText(dateFormatter.format(Date(endDateMillis!!)))
    }

    // ================== UTIL ==================
    private fun normalizarTimestamp(ts: Long): Long {
        // Si viene en segundos → convertir a milisegundos
        return if (ts < 10_000_000_000L) ts * 1000 else ts
    }

    // ================== VALIDACIONES ==================
    private fun validateSelection(): Boolean {
        if (!cbCO.isChecked && !cbCO2.isChecked && !cbPM25.isChecked) {
            Toast.makeText(
                this,
                "Selecciona al menos un sensor",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }
        return true
    }

    private fun validateDateRange(): Boolean {
        if (startDateMillis == null || endDateMillis == null) {
            Toast.makeText(
                this,
                "Selecciona un rango de fechas",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }
        if (startDateMillis!! > endDateMillis!!) {
            Toast.makeText(
                this,
                "La fecha inicio no puede ser mayor que la fecha fin",
                Toast.LENGTH_SHORT
            ).show()
            return false
        }
        return true
    }
}
