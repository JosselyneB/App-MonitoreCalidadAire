package com.example.calidadaireapp

data class RegistroSensor(
    val sensor: String,
    val valor: Float,
    val estado: String,
    val unidad: String,
    val ubicacion: String,
    val timestamp: Long
)
