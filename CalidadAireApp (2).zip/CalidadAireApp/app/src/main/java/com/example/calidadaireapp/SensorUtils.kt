package com.example.calidadaireapp

object SensorUtils {

    fun normalizarSensor(sensor: String): String {
        return sensor
            .uppercase()
            .replace(".", "")
            .replace("₂", "2")
    }
}
